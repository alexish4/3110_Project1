To run: 
Step 1: javac Project1.java
Step 2: java Project1

