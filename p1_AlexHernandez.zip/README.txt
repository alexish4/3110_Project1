To run:
Step 1: javac Project1.java
Step 2: java Project1

I am not sure if the way I coded it follows DFA style or not (atleast for recognizing the input).
I tried to follow DFA logic with my if statements but I don't know how well my code represents DFA.
If it doesn't please let me know in comments for the assignment.