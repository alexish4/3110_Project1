To run: (CODE IS NOT RUNNABLE)
Step 1: javac Project1.java
Step 2: java Project1

Incomplete, will need to visit office hours to ask for advice. 