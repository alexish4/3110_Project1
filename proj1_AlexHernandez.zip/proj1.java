import java.util.Scanner;

public class proj1 {
    
    private char [] language = ['0','1', '2','3' '4', '5', '6', '7', '8', '9', '+', '-', '.', '_', 'e', 'E', 'f', 'F', 'd', 'D'];
    private char [] digits = ['0','1', '2','3' '4', '5', '6', '7', '8', '9'];
    private char [] ending = ['f', 'F', 'd', 'D'];
    private char [] e = ['e', 'E'];
    private int eIndex = 100; //initializing to random value that won't be reached
    private int decimalIndex = 100; //initializing to random value that won't be reached
    private int exponentValue = -10000; //initializing to random value that won't be reached
    private int endingIndex = 100;
    private int tenthValue = 100;
    private int rememberSuffix = 0; 
    private int rememberE = 0;
    private int rememberUnderscore = 0;
    //private double result = 0;
    
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String input;
        System.out.println("Enter Java Floating Point Literal(Enter 'q' to end program): ");
        do {
            System.out.print(">>> ");
            input = keyboard.nextLine();
            proj1 demo = new proj1();
            int index = 0;
            double result = 0;
            demo.state1(input, index, result);
        } while (!input.equals("q"));
        System.out.println("Program Ended");
    }
    public void state1(input, index, result) {
        for (int i = 0; i < input.length; i++) { //remembering the locations of variables
            if (input.charAt(i) == '.') {
                decimalIndex = i;
            }
            else if (input.charAt(i) == 'e' || input.charAt(i) == 'E') 
                eIndex = i;
            else if (input.charAt(i) == 'f' || input.charAt(i) == 'F' || input.charAt(i) == 'd' || input.charAt(i) == 'D') 
                endingIndex = i;
        }
        if (decimalIndex != 100 && rememberE != 0)
            tenthValue = rememberDecimalPoint - 1 - countUnderScoreBeforeE;
        else if (decimalIndex == 100 && rememberE == 0)
            tenthValue = rememberSuffix - 1 - countUnderScore;
        
            
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
            || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
            || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state2(input, index + 1, result);
            }
            else if (input.charAt(index + 1) == '.')
                state3(input, index + 1, result);

        }
    } 
    public void state2(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
                || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
                || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                    || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                    state2(input, index + 1, result);
                    if (decimalIndex != 100)

            }
            else if (input.charAt(index + 1) == '.')
                state4(input, index + 1, result);
            else if (input.charAt(index + 1) == 'f' || input.charAt(index + 1) == 'F' || input.charAt(index + 1) == 'd' 
                || input.charAt(index + 1) == 'D') 
                state9(input, index + 1, result);
            else if (input.charAt(index + 1) == '_')
                state10(input, index + 1, result);

        }
    } //done with directing states
    public void state3(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
                || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
                || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                    || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state5(input, index + 1, result);
            }
        }
    } //done with directing states
    public void state4(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
                || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
                || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                    || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state5(input, index + 1, result);
            }
            else if (input.charAt(index + 1) == 'f' || input.charAt(index + 1) == 'F' || input.charAt(index + 1) == 'd' 
                || input.charAt(index + 1) == 'D') 
                state9(input, index + 1, result);
            
            
        }
    } //done with directing states
    public void state5(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
                || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
                || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                    || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state5(input, index + 1, result);
            }
            else if (input.charAt(index + 1) == 'e' || input.charAt(index + 1) == 'E') 
                state6(input, index + 1, result);
            else if (input.charAt(index + 1) == 'f' || input.charAt(index + 1) == 'F' || input.charAt(index + 1) == 'd' 
                || input.charAt(index + 1) == 'D') 
                state9(input, index + 1, result);
            else if (input.charAt(index + 1) == '_')
                state10(input, index + 1, result);
        }
    } //done with directing
    public void state6(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
                || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
                || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                    || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state8(input, index + 1, result);
            }
            else if (input.charAt(index + 1) == '+' || input.charAt(index + 1) == '-') 
                state7(input, index + 1, result);
            
        }
    } //done with directing
    public void state7(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
                || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
                || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                    || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state8(input, index + 1, result);
            }
        }
    } //done with directing
    public void state8(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '_')
                state10(input, index + 1, result);
            else if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
            || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
            || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state8(input, index + 1, result);
            }
            else if (input.charAt(index + 1) == 'f' || input.charAt(index + 1) == 'F' || input.charAt(index + 1) == 'd' 
                || input.charAt(index + 1) == 'D') 
                state9(input, index + 1, result);
        }
    } //done with directing
    public void state9(input, index, result) { //final state
        if(index != (input.length - 1) )
            System.out.println("Failed");
    }
    public void state10(input, index, result) {
        if (index < (input.length - 1) ) {
            if (input.charAt(index + 1) == '0' || input.charAt(index + 1) == '1' || input.charAt(index + 1) == '2' 
                || input.charAt(index + 1) == '3') || input.charAt(index + 1) == '4' || input.charAt(index + 1) == '5' 
                || input.charAt(index + 1) == '6' || input.charAt(index + 1) == '7'
                    || input.charAt(index + 1) == '8' || input.charAt(index + 1) == '9') {
                state2(input, index + 1, result);
            }
        }
    }
}
